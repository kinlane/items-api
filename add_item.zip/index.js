// Added to handle injection
const vandium = require( 'vandium' );

var mysql  = require('mysql');

exports.handler = vandium.generic()
    .handler( (event, context, callback) => {

  var connection = mysql.createConnection({
    host     : process.env.host,
    user     : process.env.user,
    password : process.env.password,
    database : process.env.database
  });

  var sql = "INSERT INTO items(name)";
  sql = sql + " VALUES(" + connection.escape(event.name) + ")";

  connection.query(sql, function (error, results, fields) {
  var response = {};
  response['item_id'] = results.insertId;
  response['name'] = event.name;
    
  callback( null, results );
    
  });
});