const vandium = require( 'vandium' );

var mysql      = require('mysql');

exports.handler = vandium.generic()
    .handler( (event, context, callback) => {

  var connection = mysql.createConnection({
    host     : process.env.host,
    user     : process.env.user,
    password : process.env.password,
    database : process.env.database
  });

var sql = 'CREATE TABLE `items5` (';
  sql = sql + '`item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,';
  sql = sql + '`name` varchar(100) DEFAULT NULL,';
  sql = sql + 'PRIMARY KEY (`item_id`)';
  sql = sql + ') ENGINE=InnoDB DEFAULT CHARSET=latin1';

	connection.query(sql, function (error, results, fields) {
	  callback( null, results );
  });
});