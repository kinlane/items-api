// Added to handle injection
const vandium = require( 'vandium' );

var mysql      = require('mysql');

var connection = mysql.createConnection({
    host     : process.env.host,
    user     : process.env.user,
    password : process.env.password,
    database : process.env.database
});

exports.handler = vandium.generic()
    .handler( (event, context, callback) => {

    var sql = "UPDATE items SET ";
    
    sql = sql + "name = " + connection.escape(event.name);
    
    sql = sql + " WHERE item_id = " + connection.escape(event.item_id);

	connection.query(sql, function (error, results, fields) {

  var response = {};
  response['item_id'] = event.item_id;
  response['name'] = event.name;

  callback( null, response );

  });
});